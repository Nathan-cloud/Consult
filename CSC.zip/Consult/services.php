<!DOCTYPE html>
<html lang="en">
  <head>
    <title>CSC - SERVICES	</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
 
  </head>
  <body>
  <?php include 'include/header.php'; ?>
    
    <section class="hero-wrap hero-wrap-2" style="background-image: url('assets/images/bg_1.jpg');">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center">
          <div class="col-md-9 ftco-animate text-center">
            <h1 class="mb-2 bread">Services</h1>
            <p class="breadcrumbs"><span class="mr-2"><a href="index.php">Home <i class="ion-ios-arrow-forward"></i></a></span> <span>Services <i class="ion-ios-arrow-forward"></i></span></p>
          </div>
        </div>
      </div>
    </section>

    <section class="ftco-section ftco-no-pb">
    	<div class="container">
    		<div class="row justify-content-center mb-5">
          <div class="col-md-8 text-center heading-section ftco-animate">
          	<span class="subheading">Services</span>
            <h2 class="mb-4">Why Choose Us?</h2>
            <p>Our services will help you to reach on you goals</p>
          </div>
        </div>
  			<div class="row tabulation mt-4 ftco-animate">
  				<div class="col-md-4">
						<ul class="nav nav-pills nav-fill d-md-flex d-block flex-column">
						  <li class="nav-item text-left">
						    <a class="nav-link active py-4" data-toggle="tab" href="#services-1"><span class="flaticon-analysis mr-2"></span> 
								Accounting Services</a>
						  </li>
						  <li class="nav-item text-left">
						    <a class="nav-link py-4" data-toggle="tab" href="#services-2"><span class="flaticon-business mr-2"></span> Auditing Services</a>
						  </li>
						  <li class="nav-item text-left">
						    <a class="nav-link py-4" data-toggle="tab" href="#services-3"><span class="flaticon-insurance mr-2"></span>Tax Consultacy</a>
						  </li>
						  <li class="nav-item text-left">
						    <a class="nav-link py-4" data-toggle="tab" href="#services-4"><span class="flaticon-money mr-2"></span> Business Plan Services</a>
						  </li>
						  <li class="nav-item text-left">
						    <a class="nav-link py-4" data-toggle="tab" href="#services-5"><span class="flaticon-rating mr-2"></span> Project analysis and Research</a>
						  </li>
						  <li class="nav-item text-left">
						    <a class="nav-link py-4" data-toggle="tab" href="#services-6"><span class="flaticon-search-engine mr-2"></span> Coporate Training</a>
						  </li>
						</ul>
					</div>
					<div class="col-md-8">
						<div class="tab-content">
						  <div class="tab-pane container p-0 active" id="services-1">
						  	<div class="img" style="background-image: url(assets/images/project-2.jpg);"></div>
						  	<h3><a href="#">Accounting Services</a></h3>
						  	<p>We provide a full range of accounting and bookkeeping services to enable you report to all organizational stakeholders accurately and timely.</p>
						  </div>
						  <div class="tab-pane container p-0 fade" id="services-2">
						  	<div class="img" style="background-image: url(assets/images/project-3.jpg);"></div>
						  	<h3><a href="#">Auditing Services</a></h3>
						  	<p>We perform Statutory and Tax Audits to ensure you and the organization conforms to the company policies, statutory requirements and international accepted standards.

							</p>
						  </div>
						  <div class="tab-pane container p-0 fade" id="services-3">
						  	<div class="img" style="background-image: url(assets/images/project-4.jpg);"></div>
						  	<h3><a href="#">Tax Consultacy</a></h3>
						  	<p>We perform Statutory and Tax Audits to ensure you and the organization conforms to the company policies, statutory requirements and international accepted standards.</p>
						  </div>
						  <div class="tab-pane container p-0 fade" id="services-4">
						  	<div class="img" style="background-image: url(assets/images/project-5.jpg);"></div>
						  	<h3><a href="#">Business Plan Services</a></h3>
						  	<p>We are committed on an ongoing basis to research and advice our clients on how to manage risks more effectively to help them unleash their full potential.</p>
						  </div>
						  <div class="tab-pane container p-0 fade" id="services-5">
						  	<div class="img" style="background-image: url(assets/images/project-6.jpg);"></div>
						  	<h3><a href="#">Project analysis and Research</a></h3>
						  	<p>We assist your company since its creation to its implementation by helping you solve most complex issues in distinct.</p>
						  </div>
						  <div class="tab-pane container p-0 fade" id="services-6">
						  	<div class="img" style="background-image: url(assets/images/project-1.jpg);"></div>
						  	<h3><a href="#">Coporate Training</a></h3>
						  	<p>We are committed to offer tailor made training to suite client business need on how to embrace technologies in their business.</p>
						  </div>
						</div>
					</div>
				</div>
    	</div>
    </section>

    <section class="ftco-section">
			<div class="container">
				<div class="row">
					<div class="col-lg-4 d-flex">
						<div class="services-2 border rounded text-center ftco-animate">
							<div class="icon mt-2 d-flex justify-content-center align-items-center"><span class="flaticon-analysis"></span></div>
							<div class="text media-body">
								<h3>Accounting Services</h3>
								<p>Some organizations may opt to seek external accounting services on a partial or complete basis. In the case of part time, the organizations will have staff who will compile most of the information required for consolidation of the financial reports.</p>
							</div>
						</div>
					</div>
					<div class="col-lg-4 d-flex">
						<div class="services-2 border rounded text-center ftco-animate">
							<div class="icon mt-2 d-flex justify-content-center align-items-center"><span class="flaticon-business"></span></div>
							<div class="text media-body">
								<h3>Auditing Services</h3>
								<p>The auditing services will be in accordance with the firm’s procedures which are in accordance with the international accounting and auditing standards (IAAS).</p>
							</div>
						</div>
					</div>
					<div class="col-lg-4 d-flex">
						<div class="services-2 border rounded text-center ftco-animate">
							<div class="icon mt-2 d-flex justify-content-center align-items-center"><span class="flaticon-insurance"></span></div>
							<div class="text media-body">
								<h3>Project Analysis & Research</h3>
								<p>CSC Ltd. assists your company since its creation phase to its implementation by helping you solve most complex issues in distinct.</p>
							</div>
						</div>
					</div>
					<div class="col-lg-4 d-flex">
						<div class="services-2 border rounded text-center ftco-animate">
							<div class="icon mt-2 d-flex justify-content-center align-items-center"><span class="flaticon-money"></span></div>
							<div class="text media-body">
								<h3>Business Plan Services</h3>
								<p>Following our understanding that risk is a major challenge to all organization and have been used by rivals as a competitive advantage, we are committed on an ongoing basis to research and advice our client on how to manage risk more effectively to help them unleash their full potential</p>
							</div>
						</div>
					</div>
					<div class="col-lg-4 d-flex">
						<div class="services-2 border rounded text-center ftco-animate">
							<div class="icon mt-2 d-flex justify-content-center align-items-center"><span class="flaticon-rating"></span></div>
							<div class="text media-body">
								<h3>Tax Consultancy</h3>
								<p>Give value to your business and let us advice you on accounting and taxes matters
									-  Direct Tax,
-  Tax Audits,
-  Annual Tax Returns,
-  Income Tax Compliance,
-  Withholding Tax Advisory,
-  Indirect Tax,
-  Value Added Tax Advisory,
-  Excise Duty Advisory,
-  Customs Duty Audit Assistance,
-  Commercial Taxes Assistance and Electronic ERP that can lead your business to success.
								</p>
							</div>
						</div>
					</div>
					<div class="col-lg-4 d-flex">
						<div class="services-2 border rounded text-center ftco-animate">
							<div class="icon mt-2 d-flex justify-content-center align-items-center"><span class="flaticon-search-engine"></span></div>
							<div class="text media-body">
								<h3>Corporate Training</h3>
								<p>CSC professionals are committed to offer tailor made training to suite client business need on how to embrace technology in their business, changing regulations and standards, how to maintain complete books of account, how to analyze a market using both SWOT and the balanced score card to enhance efficiency in their operations.</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>

		<?php include 'include/footer.php'; ?>
		<script src="assets/js/jquery.min.js"></script>
	<script src="assets/js/jquery-migrate-3.0.1.min.js"></script>
	<script src="assets/js/popper.min.js"></script>
	<script src="assets/js/bootstrap.min.js"></script>
	<script src="assets/js/jquery.easing.1.3.js"></script>
	<script src="assets/js/jquery.waypoints.min.js"></script>
	<script src="assets/js/jquery.stellar.min.js"></script>
	<script src="assets/js/owl.carousel.min.js"></script>
	<script src="assets/js/jquery.magnific-popup.min.js"></script>
	<script src="assets/js/aos.js"></script>
	<script src="assets/js/jquery.animateNumber.min.js"></script>
	<script src="assets/js/scrollax.min.js"></script>
	<script src="assets/js/main.js"></script>
    
  </body>
</html>