<!DOCTYPE html>
<html lang="en">
  <head>
    <title>CSC - ABOUT</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    

   
  </head>
  <body>
  <?php include 'include/header.php'; ?>
    
    <section class="hero-wrap hero-wrap-2" style="background-image: url('assets/images/bg_1.jpg');">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center">
          <div class="col-md-9 ftco-animate text-center">
            <h1 class="mb-2 bread">About Us</h1>
            <p class="breadcrumbs"><span class="mr-2"><a href="index.php">Home <i class="ion-ios-arrow-forward"></i></a></span> <span>About us <i class="ion-ios-arrow-forward"></i></span></p>
          </div>
        </div>
      </div>
    </section>

    <section class="ftco-section ftco-about ftco-no-pt ftco-no-pb ftco-counter" id="section-counter">
			<div class="container consult-wrap">
				<div class="row d-flex align-items-stretch">
					<div class="col-md-4 wrap-about align-items-stretch d-flex">
						<div class="img" style="background-image: url(assets/images/about.jpg);"></div>
					</div>
					<div class="col-md-8 wrap-about ftco-animate py-md-5 pl-md-5">
						<div class="heading-section mb-4">
							<span class="subheading">Welcome to Negotiate</span>
							<h2>The Smartest Thing To Do With Your Consulting Business</h2>
						</div>
						<p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.</p>
						<div class="tabulation-2 mt-4">
							<ul class="nav nav-pills nav-fill d-md-flex d-block">
								
							  <li class="nav-item px-lg-2">
							    <a class="nav-link active py-lg-2" data-toggle="tab" href="#home1"><span class="ion-ios-home mr-2"></span> Mission and vision</a>
							  </li>
							
							  <li class="nav-item px-lg-2">
							    <a class="nav-link py-2" data-toggle="tab" href="#home2"><span class="ion-ios-person mr-2"></span> Regulatory body and Commitment</a>
							  </li>
							  <li class="nav-item">
							    <a class="nav-link py-2" data-toggle="tab" href="#home3"><span class="ion-ios-mail mr-2"></span> Understanding</a>
							  </li>
						
							</ul>
							<div class="tab-content bg-light rounded mt-2">
							  <div class="tab-pane container p-0 active" id="home1">
							  	<p>
									  Our Vision is to be the most passionately referred consulting firm in Africa.
									  And Our mission is to provide the highest quality service to our clients by combining highly skilled team members with our proven strategies.
								  </p>
							  </div>
							  <div class="tab-pane container p-0 fade" id="home2">
							  	<p>
									The regulatory bodies for the firm and staff are the Institute of Certified Public Accountants of Rwanda (ICPAR) and Association des Taxes Advisors au Rwanda (ATAR) which issue practicing licenses every year. 
									As a medium sized firm we offer reasonable and cost effective services. 
The size of the firm enables us to respond to client needs with expediency and efficiency. 
The staff of the firm has absolute commitment to their service. 
We are dedicated to the development of accounting and auditing standards among fellow Rwandans through the advancement of professional track record.
								  </p>
							  </div>
							  <div class="tab-pane container p-0 fade" id="home3">
							  	<p>Our approach to all clients’ services is founded upon understanding of the business needs and problems within each organization. We will only render services, which we believe to be beneficial to our clients. 
									Our familiarity with business cultural, political and legal environment in Rwanda enables us to respond to the client’s needs with practical and realistic solutions.</p>
							  </div>
							</div>
						</div>

					</div>
				</div>
			</div>
		</section>

		<?php include 'include/footer.php'; ?>

		<script src="assets/js/jquery.min.js"></script>
	<script src="assets/js/jquery-migrate-3.0.1.min.js"></script>
	<script src="assets/js/popper.min.js"></script>
	<script src="assets/js/bootstrap.min.js"></script>
	<script src="assets/js/jquery.easing.1.3.js"></script>
	<script src="assets/js/jquery.waypoints.min.js"></script>
	<script src="assets/js/jquery.stellar.min.js"></script>
	<script src="assets/js/owl.carousel.min.js"></script>
	<script src="assets/js/jquery.magnific-popup.min.js"></script>
	<script src="assets/js/aos.js"></script>
	<script src="assets/js/jquery.animateNumber.min.js"></script>
	<script src="assets/js/scrollax.min.js"></script>
	<script src="assets/js/main.js"></script>
    
  </body>
</html>