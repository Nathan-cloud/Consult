<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <link rel="apple-touch-icon" sizes="76x76" href="./admin/assets/img/apple-icon.png">
  <link rel="icon" type="image/png" href="./admin/assets/img/favicon.png">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title>
    Now UI Dashboard by Creative Tim
  </title>
  <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
  <!--     Fonts and icons     -->
  <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
  <!-- CSS Files -->
  <link href="./admin/assets/css/bootstrap.min.css" rel="stylesheet" />
  <link href="./admin/assets/css/now-ui-dashboard.css?v=1.3.0" rel="stylesheet" />

</head>
<body class="user-profile">
<div class="wrapper ">
<?php include './admin/include/sidebar.php'?>
    <div class="main-panel" id="main-panel">
      <!-- Navbar -->
      <?php include './admin/include/header.php'?>
      <!-- End Navbar -->
      <div class="panel-header panel-header-sm">
      </div>
      <div class="content ml-lg-5">
        <div class="row ml-lg-5">
          <div class="col-md-8 ml-lg-5">
<?php




    include('include/connection.php');

    $id=$_GET['blog_id'];
    $delete_query="DELETE FROM blog WHERE blog_id='".$id."'";
    $query=mysqli_query($con,$delete_query);
    if(($query)=== TRUE)
    {
        echo "<center>Well deleted</center>";

    }
    else
    {
        echo "<center>Not deleted</center>";
    }
    echo '<meta http-equiv="refresh"'.'content="2; URL=tables.php?post">';



?>
  </div>
        </div>
      </div>


<?php include './admin/include/footer.php'?>
    </div>
  </div>
  <!--   Core JS Files   -->
  <script src="./admin/assets/js/core/jquery.min.js"></script>
  <script src="./admin/assets/js/core/popper.min.js"></script>
  <script src="./admin/assets/js/core/bootstrap.min.js"></script>
  <script src="./admin/assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
  <script src="./admin/assets/js/plugins/bootstrap-notify.js"></script>
  <!-- Control Center for Now Ui Dashboard: parallax effects, scripts for the example pages etc -->
  <script src="./admin/assets/js/now-ui-dashboard.min.js" type="text/javascript"></script>

</body>

</html>