<div class="sidebar" data-color="orange">
      <!--
        Tip 1: You can change the color of the sidebar using: data-color="blue | green | orange | red | yellow"
    -->
      <div class="logo">
        <a href="#" class="simple-text logo-mini">
          CSS
        </a>
        <a href="#" class="simple-text logo-normal">
          Limited
        </a>
      </div>
      <div class="sidebar-wrapper" id="sidebar-wrapper">
        <ul class="nav">
          <li>
            <a href="dashboard.php">
              <i class="now-ui-icons design_app"></i>
              <p>Dashboard</p>
            </a>
          </li>

          <li class=" ">
            <a href="user.php">
              <i class="now-ui-icons users_single-02"></i>
              <p>Add blog</p>
            </a>
          </li>
          <li>
            <a href="tables.php">
              <i class="now-ui-icons design_bullet-list-67"></i>
              <p>Table List</p>
            </a>
          </li>

        </ul>
      </div>
    </div>
























