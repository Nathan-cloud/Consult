<?php
$host="localhost";
$username="root";
$pwd="";
$db_name="csc";

$con=new mysqli($host,$username,$pwd,$db_name);
?>