<!DOCTYPE html>
<html lang="en">

<head>
	<title>CSC - HOME</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

</head>

<body>
	<?php include 'include/header.php'; ?>
	<section class="home-slider owl-carousel">
		<div class="slider-item" style="background-image:url(assets/images/bg_1.jpg);">
			<div class="overlay"></div>
			<div class="container">
				<div class="row no-gutters slider-text align-items-center justify-content-end"
					data-scrollax-parent="true">
					<div class="col-md-7 ftco-animate mb-md-5">
						<span class="subheading">CSC Ltd</span>
						<h1 class="mb-4">Your Success * Our Satisfaction</h1>
						<p><a href="#" class="btn btn-primary px-4 py-3 mt-3">Our Services</a></p>
					</div>
				</div>
			</div>
		</div>

		<div class="slider-item" style="background-image:url(assets/images/bg_2.jpg);">
			<div class="overlay"></div>
			<div class="container">
				<div class="row no-gutters slider-text align-items-center justify-content-end"
					data-scrollax-parent="true">
					<div class="col-md-7 ftco-animate mb-md-5">
						<span class="subheading">CSC Ltd</span>
						<h1 class="mb-4">Your Success * Our Satisfaction</h1>
						<p><a href="#" class="btn btn-primary px-4 py-3 mt-3">Our Services</a></p>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section class="ftco-section ftco-no-pt ftco-no-pb ftco-consult">
		<div class="container">
			<div class="row d-flex no-gutters align-items-stretch	consult-wrap">
				<div class="col-md-6 wrap-about align-items-stretch d-flex">
					<div class="ftco-animate bg-primary align-self-stretch px-4 py-5 w-100">
						<h2 class="heading-white mb-4">CSC Ltd</h2>
						<div class="services">
							<div class="icon mt-2 d-flex align-items-center"><span
									class="flaticon-collaboration"></span></div>
							<div class="text media-body">
								<h3>Accounting Services</h3>
								<p class="text-white">We provide a full range of accounting and bookkeeping services to enable you
									report to all organizational stakeholders accurately and timely. </p>
							</div>
						</div>
						<div class="services">
							<div class="icon mt-2"><span class="flaticon-analysis"></span></div>
							<div class="text media-body">
								<h3>Auditing Services</h3>
								<p class="text-white">We perform Statutory and Tax Audits to ensure you and the organization
									conforms to the company policies, statutory requirements and international
									accepted standards. </p>
							</div>
						</div>
						<div class="services">
							<div class="icon mt-2"><span class="flaticon-search-engine"></span></div>
							<div class="text media-body ">
								<h3>Tax Consultacy</h3>
								<p class="text-white">We perform Statutory and Tax Audits to ensure you and the organization conforms to the company policies, statutory requirements and international accepted standards.</p>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-6 wrap-about ftco-animate align-items-stretch d-flex">
					<div class="bg-white p-5">
						<h2 class="mb-4">Negotiate <br>A Consulting Agency</h2>
						<div class="row">
							
							<div class="col-lg-6">
								
								<div class="services">
									<div class="icon mt-2"><span class="flaticon-handshake"></span></div>
									<div class="text media-body">
										<h3>Business Plan Services</h3>
										<p>We are committed on an ongoing basis to research and advice our clients on
											how to manage risks more effectively to help them unleash their full
											potential. </p>
									</div>
								</div>
							</div>


							<div class="col-lg-6">
								<div class="services">
									<div class="icon mt-2"><span class="flaticon-search-engine"></span></div>
									<div class="text media-body">
										<h3>Project analysis and Research</h3>
										<p>We assist your company since its creation to its implementation by helping
											you solve most complex issues in distinct. </p>
									</div>
								</div>
							</div>

							<div class="col-lg-6">
								<div class="services">
									<div class="icon mt-2"><span class="flaticon-search-engine"></span></div>
									<div class="text media-body">
										<h3>Coporate Training</h3>
										<p>We are committed to offer tailor made training to suite client business need
											on how to embrace technologies in their business. </p>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section class="ftco-intro ftco-no-pb img" style="background-image: url(assets/images/bg_3.jpg);">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-md-10 text-center heading-section heading-section-white ftco-animate">
					<h2 class="mb-0">You Always Get the Best Guidance</h2>
				</div>
			</div>
		</div>
	</section>

	<section class="ftco-section ftco-about ftco-no-pt ftco-no-pb ftco-counter" id="section-counter">
		<div class="container consult-wrap">
			<div class="row d-flex align-items-stretch">
				<div class="col-md-6 wrap-about align-items-stretch d-flex">
					<div class="img" style="background-image: url(assets/images/about.jpg);"></div>
				</div>
				<div class="col-md-6 wrap-about ftco-animate py-md-5 pl-md-5">
					<div class="heading-section mb-4">
						<span class="subheading">Welcome to Negotiate</span>
						<h2>The Smartest Thing To Do With Your Consulting Business</h2>
					</div>
					<p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there
						live the blind texts.</p>
					<div class="tabulation-2 mt-4">
						<ul class="nav nav-pills nav-fill d-md-flex d-block">
							<li class="nav-item">
								<a class="nav-link active py-2" data-toggle="tab" href="#home1"><span
										class="ion-ios-home mr-2"></span> Our Mission</a>
							</li>
							<li class="nav-item px-lg-2">
								<a class="nav-link py-2" data-toggle="tab" href="#home2"><span
										class="ion-ios-person mr-2"></span> Our Vision</a>
							</li>
							<li class="nav-item">
								<a class="nav-link py-2" data-toggle="tab" href="#home3"><span
										class="ion-ios-mail mr-2"></span> Our Value</a>
							</li>
						</ul>
						<div class="tab-content bg-light rounded mt-2">
							<div class="tab-pane container p-0 active" id="home1">
								<p>Far far away, behind the word mountains, far from the countries Vokalia and
									Consonantia, there live the blind texts. Separated they live in Bookmarksgrove right
									at the coast of the Semantics, a large language ocean.</p>
							</div>
							<div class="tab-pane container p-0 fade" id="home2">
								<p>Far far away, behind the word mountains, far from the countries Vokalia and
									Consonantia, there live the blind texts. Separated they live in Bookmarksgrove right
									at the coast of the Semantics, a large language ocean.</p>
							</div>
							<div class="tab-pane container p-0 fade" id="home3">
								<p>Far far away, behind the word mountains, far from the countries Vokalia and
									Consonantia, there live the blind texts. Separated they live in Bookmarksgrove right
									at the coast of the Semantics, a large language ocean.</p>
							</div>
						</div>
					</div>

				</div>
			</div>
		</div>
	</section>





	<section class="ftco-section testimony-section">
		<div class="container-fluid px-md-5">
			<div class="row justify-content-center mb-5">
				<div class="col-md-8 text-center heading-section ftco-animate">
					<span class="subheading">Testimonies</span>
					<p>Separated they live in. A small river named Duden flows by their place and supplies it with the
						necessary regelialia. It is a paradisematic country</p>
				</div>
			</div>
			<div class="row ftco-animate justify-content-center">
				<div class="col-md-12">
					<div class="carousel-testimony owl-carousel">
						<div class="item">
							<div class="testimony-wrap d-flex">
								<div class="user-img" style="background-image: url(assets/images/person_1.jpg)">
								</div>
								<div class="text pl-4">
									<span class="quote d-flex align-items-center justify-content-center">
										<i class="icon-quote-left"></i>
									</span>
									<p>CSC Ltd has helped our business build and execute our marketing strategies, using
										fact-based research and consumer behavior to generate more revenues, leads,
										engagement and sales!</p>
									<p class="name">Grégroire HAKIZIMANA</p>
									<span class="position">SHEMA LUXURY GROUP (MD)</span>
								</div>
							</div>
						</div>
						<div class="item">
							<div class="testimony-wrap d-flex">
								<div class="user-img" style="background-image: url(assets/images/person_2.jpg)">
								</div>
								<div class="text pl-4">
									<span class="quote d-flex align-items-center justify-content-center">
										<i class="icon-quote-left"></i>
									</span>
									<p>“We are conversant with accounting, auditing, taxation consultancy and corporate
										training services. We also offers other services relating to the core services,
										this include company receivership and liquidation services and book keeping
										services.”</p>
									<p class="name">Beatrice MUJAWAYEZU</p>
									<span class="position">CHIEF EXECUTIVE OFFICER (CEO)</span>
								</div>
							</div>
						</div>
						<div class="item">
							<div class="testimony-wrap d-flex">
								<div class="user-img" style="background-image: url(assets/images/person_1.jpg)">
								</div>
								<div class="text pl-4">
									<span class="quote d-flex align-items-center justify-content-center">
										<i class="icon-quote-left"></i>
									</span>
									<p>CSC Ltd has helped our business build and execute our marketing strategies, using
										fact-based research and consumer behavior to generate more revenues, leads,
										engagement and sales!</p>
									<p class="name">Grégroire HAKIZIMANA</p>
									<span class="position">SHEMA LUXURY GROUP (MD)</span>
								</div>
							</div>
						</div>
						<div class="item">
							<div class="testimony-wrap d-flex">
								<div class="user-img" style="background-image: url(assets/images/person_2.jpg)">
								</div>
								<div class="text pl-4">
									<span class="quote d-flex align-items-center justify-content-center">
										<i class="icon-quote-left"></i>
									</span>
									<p>“We are conversant with accounting, auditing, taxation consultancy and corporate
										training services. We also offers other services relating to the core services,
										this include company receivership and liquidation services and book keeping
										services.”</p>
									<p class="name">Beatrice MUJAWAYEZU</p>
									<span class="position">CHIEF EXECUTIVE OFFICER (CEO)</span>
								</div>
							</div>
						</div>

					</div>
				</div>
			</div>
		</div>
	</section>

	<hr>


	<?php include 'include/footer.php'; ?>

	<script src="assets/js/jquery.min.js"></script>
	<script src="assets/js/jquery-migrate-3.0.1.min.js"></script>
	<script src="assets/js/popper.min.js"></script>
	<script src="assets/js/bootstrap.min.js"></script>
	<script src="assets/js/jquery.easing.1.3.js"></script>
	<script src="assets/js/jquery.waypoints.min.js"></script>
	<script src="assets/js/jquery.stellar.min.js"></script>
	<script src="assets/js/owl.carousel.min.js"></script>
	<script src="assets/js/jquery.magnific-popup.min.js"></script>
	<script src="assets/js/aos.js"></script>
	<script src="assets/js/jquery.animateNumber.min.js"></script>
	<script src="assets/js/scrollax.min.js"></script>
	<script src="assets/js/main.js"></script>

</body>

</html>