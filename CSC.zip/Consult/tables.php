<?php
include './admin/include/connection.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <link rel="apple-touch-icon" sizes="76x76" href="./admin/assets/img/apple-icon.png">
  <link rel="icon" type="image/png" href="./admin/assets/img/favicon.png">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title>
    Now UI Dashboard by Creative Tim
  </title>
  <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
  <!--     Fonts and icons     -->
   <!-- CSS Files -->
   <link href="./admin/assets/css/dataTables.bootstrap4.min.css" rel="stylesheet">
  <link href="./admin/assets/css/bootstrap.min.css" rel="stylesheet" />
  <link href="./admin/assets/css/now-ui-dashboard.css" rel="stylesheet" />
  <link href="./admin/assets/css/font-awesome.min.css" rel="stylesheet" />

</head>

<body class="">
  <div class="wrapper ">
    <?php include './admin/include/sidebar.php'?>
    <div class="main-panel" id="main-panel">
      <!-- Navbar -->
      <?php include './admin/include/header.php'?>
      <!-- End Navbar -->
      <div class="panel-header panel-header-sm">
      </div>
      <div class="content">
        <div class="row">
          <div class="col-md-12">
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">DataTables Example</h6>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
        
                    <tr>
                      <th>ID</th>
                      <th>BLOG TITLE</th>
                      <th>BLOG IMG</th>
                      <th>BLOG STORY</th>
                      <th>ACTION</th>
                      
                    </tr>
                  </thead>
                  <tfoot>
                    <tr>
                    <th>ID</th>
                      <th>BLOG TITLE</th>
                      <th>BLOG IMG</th>
                      <th>BLOG STORY</th>
                      <th>ACTION</th>
                    </tr>
                  </tfoot>
                  <tbody>
           
                    <tr>
                    <?php 
        

        $read="SELECT * FROM blog ORDER BY blog_title ASC ";
        
        $data=$con->query($read);
        
        if($data -> num_rows > 0){
          while($row=$data -> fetch_assoc()){
                
                ?>
                      <td><?php echo $row['blog_id'];?></td>
                      <td><?php echo $row['blog_title'];?></td>
                      <td><img src="<?php echo $row['blog_img'];?>" width="65" alt=""></td>
                      <td class="d-block"><?php echo $row['blog_story'];?></td>
                      <td>
                        <?php
                          echo "<a class='btn btn-primary btn-circle p-2' href='update.php?blog_id=".$row['blog_id']."&blog_title=".$row['blog_title']."&blog_story=".$row['blog_story']."&blog_img=".$row['blog_img']."'><i class='fa fa-edit'></i></a>";
                          echo "<a class='btn btn-danger btn-circle p-2' href='delete.php?blog_id=".$row['blog_id']."&blog_title=".$row['blog_title']."&blog_story=".$row['blog_story']."&blog_img=".$row['blog_img']."'><i class='fa fa-trash'></i></a>";
              
                          ?>
                      </td>
                     
                    </tr>
                    <?php
}
}
else{
    echo "<h5 class='bread text-center'>NO BLOG AVAIABLE RIGHT NOW</h5>";
}
?>
                  </tbody>
                </table>

              </div>
            </div>
          </div>
        </div>
      </div>
      <?php include './admin/include/footer.php'?>
    </div>
  </div>
  <!--   Core JS Files   -->
  <!--   Core JS Files   -->
  <script src="./admin/assets/js/core/jquery.min.js"></script>
  <script src="./admin/assets/js/core/popper.min.js"></script>
  <script src="./admin/assets/js/core/bootstrap.min.js"></script>
  <script src="./admin/assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
  <script src="./admin/assets/js/plugins/bootstrap-notify.js"></script>
  <!-- Control Center for Now Ui Dashboard: parallax effects, scripts for the example pages etc -->
  <script src="./admin/assets/js/now-ui-dashboard.min.js" type="text/javascript"></script>
  <script src="./admin/assets/js/jquery.dataTables.min.js"></script>
  <script src="./admin/assets/js/dataTables.bootstrap4.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="./admin/assets/js/datatables-demo.js"></script>
</body>

</html>