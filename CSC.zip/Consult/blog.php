<?php
include 'include/connection.php';
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <title>CSC - BLOG</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  </head>
  <body>
  <?php include 'include/header.php'; ?>
    <section class="hero-wrap hero-wrap-2" style="background-image: url('assets/images/bg_1.jpg');">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center">
          <div class="col-md-9 ftco-animate text-center">
            <h1 class="mb-2 bread">Blog</h1>
            <p class="breadcrumbs"><span class="mr-2"><a href="index.php">Home <i class="ion-ios-arrow-forward"></i></a></span> <span>Blog <i class="ion-ios-arrow-forward"></i></span></p>
          </div>
        </div>
      </div>
    </section>
		
		<section class="ftco-section">
			<div class="container">
				<div class="row">
 
        <?php 
        

$read="SELECT * FROM blog ORDER BY blog_title ASC ";

$data=$con->query($read);

if($data -> num_rows > 0){
	while($row=$data -> fetch_assoc()){
        
        ?>
      <div class="col-md-6 col-lg-4 ftco-animate">
        <div class="blog-entry">
            <div class="card-deck">
                <div class="card">
                  <img src="<?php echo $row['blog_img']; ?>" class="card-img-top block-20 d-flex align-items-end" alt="...">
                  <div class="card-body text">
                    <h5 class="heading"><a href="#"><?php echo $row['blog_title']?></a></h5>
                    <p class="card-text"><?php echo $row['blog_story']   ?></p>
                  </div>
                  <div class="card-footer d-flex align-items-center mt-4r">
                    <p class="mb-0"><a href="#" class="btn btn-primary btn-sm">Read More <span class="ion-ios-arrow-round-forward"></span></a></p>
                  <p class="ml-auto mb-0 d">
                <a href="#" class="mr-2">Admin</a></p>
                  </div>
                </div>

              </div>
          </div>
      </div>
       
<?php
}
}
else{
    echo "<h5 class='bread text-center'>NO BLOG AVAIABLE RIGHT NOW</h5>";
}
?>


          </div>
        </div>
       
		</section>
		
    <?php include 'include/footer.php'; ?>



    <script src="assets/js/jquery.min.js"></script>
	<script src="assets/js/jquery-migrate-3.0.1.min.js"></script>
	<script src="assets/js/popper.min.js"></script>
	<script src="assets/js/bootstrap.min.js"></script>
	<script src="assets/js/jquery.easing.1.3.js"></script>
	<script src="assets/js/jquery.waypoints.min.js"></script>
	<script src="assets/js/jquery.stellar.min.js"></script>
	<script src="assets/js/owl.carousel.min.js"></script>
	<script src="assets/js/jquery.magnific-popup.min.js"></script>
	<script src="assets/js/aos.js"></script>
	<script src="assets/js/jquery.animateNumber.min.js"></script>
	<script src="assets/js/scrollax.min.js"></script>
	<script src="assets/js/main.js"></script>
  </body>
</html>